import serial

while 1 :
    ser = serial.Serial('/dev/ttyACM0', 9600)
    ser.write('3')
